path = "/home/johndoe/.config/google-chrome/"
key = 'e8c9ce01d39f8f4d088599ad8427d72e' #paste the key inside the single quotes; do the same for the secret
secret = '2605d722'
operatingsystem = 'Windows' #replace Windows with Linux or Mac if you are using either of those OSs
