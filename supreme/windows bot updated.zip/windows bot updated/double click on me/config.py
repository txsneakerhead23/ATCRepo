#!/usr/bin/python
# -*- coding: utf-8 -*-

path = "/path/to/your/chrome/profile"

key = "key"

secret = "secret"


name = "John Doe"

email = "grandstreetsupreme@gmail.com"

firsttel = "000"

midtel = "000"

lasttel = "0000"

address = "4 Hypebeast Plaza"

zipe = "11111"

ccnumber = "1111111111111111"

cvv = "000"