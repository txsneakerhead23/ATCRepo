path = "/path/to/your/chrome/profile"
key = 'yourkey' #paste the key inside the single quotes; do the same for the secret
secret = 'yoursecret'
operatingsystem = 'Windows' #replace Windows with Linux or Mac if you are using either of those OSs
